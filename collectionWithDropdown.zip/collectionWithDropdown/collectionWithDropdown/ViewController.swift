//
//  ViewController.swift
//  collectionWithDropdown
//
//  Created by S@ur@bh on 12/14/19.
//  Copyright © 2019 S@ur@bh. All rights reserved.
//

import UIKit
import Alamofire
import iOSDropDown

class collectionviewCell: UICollectionViewCell {
    @IBOutlet var imgview : UIImageView!
    @IBOutlet var lblName : UILabel!
    @IBOutlet var lblSubName : UILabel!
    
}

class collectionviewHeader : UICollectionReusableView
{
    @IBOutlet var lblHeader : UILabel!
}

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    @IBOutlet var collectionview : UICollectionView!
   // static let sectionHeader = "collectionviewHeader"
    @IBOutlet var lblAllData : UILabel!
    @IBOutlet weak var txtDropDown : DropDown!
    var arrCollectionData : [AnyObject] = []
    var strTitleHeader : String!

    override func viewDidLoad() {
        super.viewDidLoad()
        txtDropDown.isSearchEnable = false
        txtDropDown.checkMarkEnabled = false
        strTitleHeader = txtDropDown.text
        let layout = collectionview.collectionViewLayout as? UICollectionViewFlowLayout
        layout?.sectionHeadersPinToVisibleBounds = true
        let param1 : [String : Any] =                  ["CompanyID":1,"MenuID":0,"SubCategoryID":0,"ImageSize":"small","SearchMerchant":""]
        
        print(param1)

        var paramsFinal : [String : Any] = [:]
                
        do {
            let data = try JSONSerialization.data(withJSONObject: param1, options: [])
            if let string = String(data: data, encoding: String.Encoding.utf8) {
                paramsFinal["params"] = string
            }
        } catch {
            print(error)
        }
        
        self.loadData(param: paramsFinal)
    }
    
    //MARK : Webservice Call Load Data
    func loadData(param : Any)
    {
       let url = "https://staging.sunteccity.com.sg/ver16/index.php/apitokenv4/list/model/merchant"
        
        Alamofire.request(url, method:.post, parameters:param as? Parameters, headers:["issecuritydisable":"0"]).responseJSON { response in
        switch response.result {
        case .success:
            print(response)
            let responseDict = response.result.value as! [String : AnyObject]
            self.arrCollectionData = responseDict["PremiumMerchant"] as! [AnyObject]
            var dataDropdown = [String]()
            for character in self.arrCollectionData {
                if let storename = character["StoreName"] {
                    dataDropdown.append(storename as! String)
                    print(dataDropdown)
                }
            }
           
            self.txtDropDown.optionArray = dataDropdown
            self.txtDropDown.didSelect{(selectedText , index , id) in
                self.lblAllData.text = "\(selectedText)"
                self.strTitleHeader = selectedText
                self.collectionview.reloadData()
            }
            self.collectionview.reloadData()
        case .failure(let error):
            print(error)
        }
        }
    }
    
    //MARK : Collectionview Delegate
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return self.arrCollectionData.count
    }
        
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionviewCell", for: indexPath as IndexPath) as! collectionviewCell
            cell.backgroundColor = UIColor.cyan
            let dictdata : [String : AnyObject] = self.arrCollectionData[indexPath.row] as! [String : AnyObject]
            
            cell.lblName.text = (dictdata["StoreName"] as! String)
            cell.lblSubName.text = (dictdata["TowerNumber"] as! String)
            
            cell.imgview.image = nil //cell.imgCollection.imageFromServerURL(dictdata["PromotionalImage"] as! String, placeHolder: UIImage.init())
            
            cell.imgview.downloaded(from: dictdata["PromotionalImage"] as! String)
            return cell
        }
    
    func collectionView(_ collectionView: UICollectionView,
                                 viewForSupplementaryElementOfKind kind: String,
                                 at indexPath: IndexPath) -> UICollectionReusableView {
      // 1
      switch kind {
      // 2
      case UICollectionView.elementKindSectionHeader:
        // 3
        guard
          let headerView = collectionView.dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: "collectionviewHeader",
            for: indexPath) as? collectionviewHeader
          else {
            fatalError("Invalid view type")
        }
        
        headerView.lblHeader.text = strTitleHeader
        return headerView
      default:
        // 4
        assert(false, "Invalid element type")
      }
    }
    
    
}




    //MARK : Imageview Extension
    extension UIImageView {
        func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleToFill) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
            contentMode = mode
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard
                    let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                    let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                    let data = data, error == nil,
                    let image = UIImage(data: data)
                    else { return }
                DispatchQueue.main.async() {
                    self.image = image
                }
            }.resume()
        }
        
        func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleToFill) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
            guard let url = URL(string: link) else { return }
            downloaded(from: url, contentMode: mode)
        }
    }
    

